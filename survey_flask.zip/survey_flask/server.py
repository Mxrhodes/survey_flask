from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = "vsdkjnfskj/nsknjscdckj"
# our index route will handle rendering our form

USERS = []

@app.route('/')
def index():
  return render_template("index.html")
# this route will handle our form submission
# notice how we defined which HTTP methods are allowed by this route
@app.route('/results', methods=['POST'])
def surey_info():
   # we'll talk about the following two lines after we learn a little more
   # about forms
    #name = request.form['name']
    #location = request.form['location']
    #language = request.form['language']
    #comment = request.form['comment']
    #count = 1
    #the_info = str(count) + " - Name: " + name + " - location: " + location +" - Favorite language: " + language + " - Thier Comment: " + comment
    #USERS.append(the_info)
    #for user in USERS:
    #    count += 1
    #    print "Got Post Info"
    #    print user
    session["name"] = request.form["name"]
    session["location"] = request.form["location"]
    session["language"] = request.form["language"]
    session["comment"] = request.form["comment"]
   # redirects back to the '/' route
    return render_template("results.html")
app.run(debug=True) # run our server